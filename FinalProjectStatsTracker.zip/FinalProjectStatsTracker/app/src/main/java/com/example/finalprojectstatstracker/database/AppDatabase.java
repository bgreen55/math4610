package com.example.finalprojectstatstracker.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.finalprojectstatstracker.models.Game;
import com.example.finalprojectstatstracker.models.Season;

@Database(entities = {Season.class, Game.class}, version = 1)                 // other entities like games also goes here
public abstract class AppDatabase extends RoomDatabase {
    public abstract SeasonsDao getSeasonDao();
    public abstract GamesDao getGamesDao();
}
