package com.example.finalprojectstatstracker.fragments;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.finalprojectstatstracker.R;
import com.example.finalprojectstatstracker.viewmodel.GameViewModel;
import com.example.finalprojectstatstracker.viewmodel.SeasonViewModel;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class AddGameFragment extends Fragment {
    private boolean previouslySaving = false;
    public AddGameFragment() { super(R.layout.fragment_add_game); }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        GameViewModel viewModel = new ViewModelProvider(getActivity()).get(GameViewModel.class);
        SeasonViewModel seasonViewModel = new ViewModelProvider(getActivity()).get(SeasonViewModel.class);


        viewModel.getSaving().observe(getViewLifecycleOwner(), (saving) -> {
            if (saving && !previouslySaving) {
                MaterialButton button = view.findViewById(R.id.saveGame);
                button.setEnabled(false);
                button.setText("Saving...");
                previouslySaving = saving;
            } else if (previouslySaving && !saving) {
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });
        view.findViewById(R.id.saveGame).setOnClickListener(saveButton -> {
            TextInputEditText teamPlayed = view.findViewById(R.id.EditVsTeam);
            TextInputEditText goals = view.findViewById(R.id.editGoals);
            TextInputEditText assists = view.findViewById(R.id.editAssist);
            TextInputEditText notes = view.findViewById(R.id.editNotes);
            TextInputEditText gameOutcome = view.findViewById(R.id.editWinOrLoss);

            viewModel.saveGameCommand(teamPlayed.getText().toString(),
                    goals.getText().toString(),
                    assists.getText().toString(),
                    gameOutcome.getText().toString(),
                    notes.getText().toString(),
                    seasonViewModel.getCurrentSeason().getValue().id   // this gives each game its season so when the season loads its games it knows which games to load
            );


        });
    }
}
