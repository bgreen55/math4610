package com.example.finalprojectstatstracker.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class GameViewModelFactory extends ViewModelProvider.AndroidViewModelFactory {

    private final long seasonId;
    private final Application application;

    public GameViewModelFactory(@NonNull Application application, long seasonId) {
        super(application);
        this.seasonId = seasonId;
        this.application = application;

    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {

            return (T) new GameViewModel(application, seasonId);

    }
}
