package com.example.finalprojectstatstracker.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.finalprojectstatstracker.models.Game;

import java.util.List;

@Dao
public interface GamesDao {
    @Insert
    public long insert(Game game);

    @Query("SELECT * FROM game")
    public List<Game> getAll();

    @Query("SELECT * FROM game WHERE seasonId = :seasonId")
    public List<Game> findBySeasonId(long seasonId);

    @Update
    public void update(Game game);

    @Delete
    public void delete(Game game);

}
