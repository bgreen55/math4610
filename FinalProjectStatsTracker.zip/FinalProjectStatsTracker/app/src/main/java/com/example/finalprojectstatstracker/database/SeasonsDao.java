package com.example.finalprojectstatstracker.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.finalprojectstatstracker.models.Season;

import java.util.List;

@Dao
public interface SeasonsDao {
    @Insert
    public long insert(Season season);

    @Query("SELECT * FROM season")
    public List<Season> getAll();

    @Query("SELECT * FROM season WHERE id = :id LIMIT 1")
    public Season findById(long id);

    @Update
    public void update(Season season);

    @Delete
    public void delete(Season season);

}
