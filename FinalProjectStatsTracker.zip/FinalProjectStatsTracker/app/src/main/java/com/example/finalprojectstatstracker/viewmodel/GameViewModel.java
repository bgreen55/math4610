package com.example.finalprojectstatstracker.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.databinding.ObservableArrayList;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.room.Room;

import com.example.finalprojectstatstracker.database.AppDatabase;
import com.example.finalprojectstatstracker.models.Game;
import com.example.finalprojectstatstracker.models.Season;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class GameViewModel extends AndroidViewModel {

    private AppDatabase db;
    private MutableLiveData<Boolean> saving = new MutableLiveData<>();
    private ObservableArrayList<Game> games = new ObservableArrayList<>();
    //SeasonViewModel viewModel = new ViewModelProvider(SeasonViewModel.class);
    //private MutableLiveData<Season> currentSeason = new MutableLiveData<>();
    private MutableLiveData<Game> currentgame = new MutableLiveData<>();

    public GameViewModel(@NonNull Application application) {
        super(application);
        saving.setValue(false);
        db = Room.databaseBuilder(application, AppDatabase.class, "gamesdb").build();
    }

    public GameViewModel(@NonNull Application application, long seasonId) {
        super(application);
        System.out.println("seasonId = " + seasonId);

        saving.setValue(false);
        db = Room.databaseBuilder(application, AppDatabase.class, "gamesdb").build();

        new Thread(() -> {
            System.out.println("WE ARE IN THE THREAD");
            //ArrayList<Game> gameList = (ArrayList<Game>) db.getGamesDao().findBySeasonId(seasonId); //    or ,getAll()
            List<Game> gameList =
            db.getGamesDao().getAll().stream().filter(game -> {
                System.out.println("Game season id = " + game.seasonId);
                return game.seasonId == seasonId;

            }).collect(Collectors.toList()
            );

            games.addAll(gameList);
        });
    }

    //public MutableLiveData<Season> getCurrentSeason() { return currentSeason; }

    public MutableLiveData<Game> getCurrentGame() { return currentgame; }

    public MutableLiveData<Boolean> getSaving() { return saving; }

    public ObservableArrayList<Game> getGames() { return games; }

    public void saveGameCommand(String vsTeam, String goals, String assists, String outCome, String notes, long currentSeason) {
        saving.setValue(true);
        new Thread(() -> {
            Game newGame = new Game();
            //newGame.gameNumber = gameNumber;
            newGame.vsTeam = vsTeam;
            newGame.gameNumber =  games.size() - 1;
            newGame.assists = assists;
            newGame.notes = notes;
            newGame.goals = goals;
            newGame.winOrloss = outCome;
            newGame.seasonId = currentSeason;
            newGame.gameId = db.getGamesDao().insert(newGame);

            games.add(newGame);
            saving.postValue(false);

            System.out.println("seasonId in save game = " + newGame.seasonId);
        }).start();
    }


}
