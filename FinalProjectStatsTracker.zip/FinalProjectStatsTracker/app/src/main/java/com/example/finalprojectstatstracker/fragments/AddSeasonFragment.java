package com.example.finalprojectstatstracker.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.finalprojectstatstracker.R;
import com.example.finalprojectstatstracker.databinding.FragmentAddSeasonBinding;
import com.example.finalprojectstatstracker.viewmodel.SeasonViewModel;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class AddSeasonFragment extends Fragment {
    private boolean previouslySaving = false;
    public AddSeasonFragment() { super(R.layout.fragment_add_season); }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SeasonViewModel viewModel = new ViewModelProvider(getActivity()).get(SeasonViewModel.class);
        viewModel.getSaving().observe(getViewLifecycleOwner(), (saving) -> {
           if (saving && !previouslySaving) {
               MaterialButton button = view.findViewById(R.id.saveSeason);
               button.setEnabled(false);
               button.setText("Saving...");
               previouslySaving = saving;
           } else if (previouslySaving && !saving) {
               getActivity().getSupportFragmentManager().popBackStack();
           }
        });
        view.findViewById(R.id.saveSeason).setOnClickListener(saveButton -> {
            TextInputEditText seasonEditText = view.findViewById(R.id.seasonEditText);
            viewModel.saveSeasonCommand(seasonEditText.getText().toString());

        });


    }
}
