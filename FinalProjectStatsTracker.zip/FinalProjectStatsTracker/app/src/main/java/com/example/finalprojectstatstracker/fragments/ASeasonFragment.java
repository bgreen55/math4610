package com.example.finalprojectstatstracker.fragments;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.ObservableArrayList;
import androidx.databinding.ObservableList;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalprojectstatstracker.GameAdapter;
import com.example.finalprojectstatstracker.R;
import com.example.finalprojectstatstracker.models.Game;
import com.example.finalprojectstatstracker.models.Season;
import com.example.finalprojectstatstracker.viewmodel.GameViewModel;
import com.example.finalprojectstatstracker.viewmodel.GameViewModelFactory;
import com.example.finalprojectstatstracker.viewmodel.SeasonViewModel;

public class ASeasonFragment extends Fragment {
    public ASeasonFragment() {
        super(R.layout.fragment_a_season);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SeasonViewModel viewModel = new ViewModelProvider(getActivity()).get(SeasonViewModel.class);
        //GameViewModel gameViewModel = new ViewModelProvider(getActivity()).get(GameViewModel.class);
//        GameViewModel gameViewModel = new ViewModelProvider(this,
//                new GameViewModelFactory(getActivity().getApplication(), viewModel.getCurrentSeason().getValue().id))
//                .get(GameViewModel.class);
        GameViewModel gameViewModel = new GameViewModel(getActivity().getApplication(), viewModel.getCurrentSeason().getValue().id);

        viewModel.getCurrentSeason().observe(getViewLifecycleOwner(), (season) -> {
            TextView nameView = view.findViewById(R.id.seasonNameTextView);
            nameView.setText(season.name + " season");
        });

        ObservableArrayList games = gameViewModel.getGames();
        System.out.println("The list of games for the season");
        System.out.println(games);
        for (Object game: games) {
            Game game1 = ((Game) game);
            System.out.printf("%s , %s \n", game1.gameId, game1.seasonId);
        }


        GameAdapter adapter = new GameAdapter(games, viewModel.getCurrentSeason().getValue());

        games.addOnListChangedCallback(new ObservableList.OnListChangedCallback() {
            @Override
            public void onChanged(ObservableList sender) {
                getActivity().runOnUiThread(() -> {
                    adapter.notifyDataSetChanged();
                });
            }

            @Override
            public void onItemRangeChanged(ObservableList sender, int positionStart, int itemCount) {
                getActivity().runOnUiThread(() -> {
                    adapter.notifyItemRangeChanged(positionStart, itemCount);
                });
            }

            @Override
            public void onItemRangeInserted(ObservableList sender, int positionStart, int itemCount) {
                getActivity().runOnUiThread(() -> {
                    adapter.notifyItemRangeInserted(positionStart, itemCount);
                });
            }

            @Override
            public void onItemRangeMoved(ObservableList sender, int fromPosition, int toPosition, int itemCount) {
                getActivity().runOnUiThread(()-> {
                    adapter.notifyItemMoved(fromPosition, itemCount);
                });
            }

            @Override
            public void onItemRangeRemoved(ObservableList sender, int positionStart, int itemCount) {
                getActivity().runOnUiThread(() -> {
                    adapter.notifyItemRangeRemoved(positionStart, itemCount);
                });
            }
        });
        

        RecyclerView gameRecyclerView = view.findViewById(R.id.gamesRecyclerView);
        gameRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        gameRecyclerView.setAdapter(adapter);

        view.findViewById(R.id.addGamefab).setOnClickListener(fab -> {
            System.out.println("Clicked add Game floaing action button");
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragmentContainerView, AddGameFragment.class, null)
                    .setReorderingAllowed(true)
                    .addToBackStack(null)
                    .commit();
        });
    }
}
