package com.example.finalprojectstatstracker.models;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Season {
    @PrimaryKey(autoGenerate = true)
    public long id;

    @ColumnInfo
    public String name;

}
