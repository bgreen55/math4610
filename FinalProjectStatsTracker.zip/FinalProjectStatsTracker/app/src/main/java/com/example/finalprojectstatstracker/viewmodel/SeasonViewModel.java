package com.example.finalprojectstatstracker.viewmodel;

import android.app.Application;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.databinding.ObservableArrayList;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;
import androidx.room.Room;

import com.example.finalprojectstatstracker.SeasonAdapter;
import com.example.finalprojectstatstracker.database.AppDatabase;
import com.example.finalprojectstatstracker.models.Season;

import java.util.ArrayList;


public class SeasonViewModel extends AndroidViewModel {
    private AppDatabase db;
    private MutableLiveData<Boolean> saving = new MutableLiveData<>();
    private ObservableArrayList<Season> seasons = new ObservableArrayList<>();
    private MutableLiveData<Season> currentSeason = new MutableLiveData<>();


    public SeasonViewModel(@NonNull Application application) {
        super(application);
        saving.setValue(false);
        db = Room.databaseBuilder(application, AppDatabase.class, "seasondb").build();

        new Thread(() -> {
            ArrayList<Season> season = (ArrayList<Season>) db.getSeasonDao().getAll();
            seasons.addAll(season);
        }).start();

    }

    public MutableLiveData<Season> getCurrentSeason() {
        return currentSeason;
    }

    public void setCurrentSeason(Season season) {
        this.currentSeason.setValue(season);
    }

    public MutableLiveData<Boolean> getSaving() {
        return saving;
    }

    public ObservableArrayList<Season> getSeasons() {
        return seasons;
    }


    public void saveSeasonCommand(String year) {
        saving.setValue(true);
        new Thread(() -> {
            Season newSeason = new Season();
            newSeason.name = year;
            newSeason.id = db.getSeasonDao().insert(newSeason);


            seasons.add(newSeason);
            saving.postValue(false); // setValue cant be used inside of a thread
        }).start();

    }



}
