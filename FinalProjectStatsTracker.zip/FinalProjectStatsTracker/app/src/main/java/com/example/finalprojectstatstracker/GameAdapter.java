package com.example.finalprojectstatstracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.databinding.ObservableArrayList;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalprojectstatstracker.models.Game;
import com.example.finalprojectstatstracker.models.Season;

public class GameAdapter extends RecyclerView.Adapter<GameAdapter.ViewHolder> {
    private ObservableArrayList<Game> games;

    Season season;

    public GameAdapter(ObservableArrayList<Game> games, Season season) {
        this.games = games;
        this.season = season;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.game_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TextView goals = holder.itemView.findViewById(R.id.goals);
        goals.setText(games.get(position).goals);

        TextView assists = holder.itemView.findViewById(R.id.assists);
        assists.setText(games.get(position).assists);

        TextView outCome = holder.itemView.findViewById(R.id.winOrLoss);
        outCome.setText(games.get(position).winOrloss);

        TextView vsTeam = holder.itemView.findViewById(R.id.vsTeam);
        vsTeam.setText(games.get(position).vsTeam);

        TextView notes = holder.itemView.findViewById(R.id.notes);
        notes.setText(games.get(position).notes);

    }

    @Override
    public int getItemCount() {
        return games.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public ViewHolder(@NonNull View itemView) { super(itemView); }
    }
}
