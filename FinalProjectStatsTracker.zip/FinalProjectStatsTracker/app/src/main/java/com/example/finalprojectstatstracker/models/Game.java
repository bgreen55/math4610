package com.example.finalprojectstatstracker.models;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Game {

    @PrimaryKey(autoGenerate = true)
    public long gameId;

    @ColumnInfo       // I am going to pass the seasons key here to know what season the game belongs too
    public long seasonId;

    @ColumnInfo
    public String vsTeam;

    @ColumnInfo
    public String goals;

    @ColumnInfo
    public String assists;

    @ColumnInfo
    public String winOrloss;

    @ColumnInfo
    public int gameNumber;

    @ColumnInfo
    public String notes;

}
