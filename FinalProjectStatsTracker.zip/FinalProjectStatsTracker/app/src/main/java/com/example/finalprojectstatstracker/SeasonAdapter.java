package com.example.finalprojectstatstracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.databinding.ObservableArrayList;
import androidx.databinding.ObservableList;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalprojectstatstracker.models.Season;

import java.util.Observable;

public class SeasonAdapter extends RecyclerView.Adapter<SeasonAdapter.ViewHolder> {
    private ObservableArrayList<Season> seasons;

    public interface OnSeasonClicked {
        public void onClick(Season season);
    }

    OnSeasonClicked listener;

    public SeasonAdapter(ObservableArrayList<Season> seasons, OnSeasonClicked listener) {
        this.seasons = seasons;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.season_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SeasonAdapter.ViewHolder holder, int position) {
        // the season year is the same thing as the name of the season
        TextView textView = holder.itemView.findViewById(R.id.seasonYear);
        textView.setText(seasons.get(position).name);


        holder.itemView.setOnClickListener(view -> {
            listener.onClick(seasons.get(position));
        });

    }

    @Override
    public int getItemCount() {
        return seasons.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}















//This was the previous constructor, then i moved the observing the array list into thes seasons fragment

//
//        this.seasons = seasons;
//
//
//        this.seasons.addOnListChangedCallback(new ObservableList.OnListChangedCallback<ObservableList<Season>>() {
//            @Override
//            public void onChanged(ObservableList<Season> sender) {
//                notifyDataSetChanged();
//            }
//
//            @Override
//            public void onItemRangeChanged(ObservableList<Season> sender, int positionStart, int itemCount) {
//                notifyItemRangeChanged(positionStart, itemCount);
//            }
//
//            @Override
//            public void onItemRangeInserted(ObservableList<Season> sender, int positionStart, int itemCount) {
//                notifyItemRangeInserted(positionStart, itemCount);
//            }
//
//            @Override
//            public void onItemRangeMoved(ObservableList<Season> sender, int fromPosition, int toPosition, int itemCount) {
//                notifyItemMoved(fromPosition, toPosition); // this program actually wont use this becuse we wont allow them to reorder
//            }
//
//            @Override
//            public void onItemRangeRemoved(ObservableList<Season> sender, int positionStart, int itemCount) {
//                notifyItemRangeRemoved(positionStart, itemCount);
//            }
//        });
//
//    }
//
