package com.example.bradleyscalculator;

import android.content.Context;
import android.widget.GridLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;

public class CalculatorButton extends AppCompatButton {

    public CalculatorButton(@NonNull Context context, CalculatorButtonData data) {
        super(context);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.rowSpec = GridLayout.spec(data.row, 1, 1);
        params.columnSpec = GridLayout.spec(data.col, data.colSpan, 1);
        params.setMargins(10, 10, 10, 10);
        setText(data.text);
        setTextSize(30);
        setBackgroundColor(getResources().getColor(R.color.my_color, null));
        setLayoutParams(params);
    }
}
