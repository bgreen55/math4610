package com.example.bradleyscalculator;

public class CalculatorButtonData {
    public enum ButtonType {
        NUMBER,
        OPERATOR,
        CLEAR,
        EQUALS,
    }

    public String text;
    public int row;
    public int col;
    public int colSpan;
    public ButtonType buttonType;

    public CalculatorButtonData(String text, int row, int col, int colSpan, ButtonType buttonType) {
        this.text = text;
        this.row = row;
        this.col = col;
        this.colSpan = colSpan;
        this.buttonType = buttonType;
    }

    public CalculatorButtonData(String text, int row, int col, int colSpan) {
        this(text, row, col, colSpan, ButtonType.NUMBER);
    }
}
