package com.example.bradleyscalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        GridLayout mainLayout = new GridLayout(this);
        mainLayout.setBackgroundColor(getResources().getColor(R.color.white, null));
        ArrayList<CalculatorButtonData> buttonData = new ArrayList<CalculatorButtonData>() {
            {
                add(new CalculatorButtonData("1", 1, 0, 1));
                add(new CalculatorButtonData("2", 1, 1, 1));
                add(new CalculatorButtonData("3", 1, 2, 1));
                add(new CalculatorButtonData(" + ", 1, 3, 1, CalculatorButtonData.ButtonType.OPERATOR));
                add(new CalculatorButtonData("4", 2, 0, 1));
                add(new CalculatorButtonData("5", 2, 1, 1));
                add(new CalculatorButtonData("6", 2, 2, 1));
                add(new CalculatorButtonData(" - ", 2, 3, 1, CalculatorButtonData.ButtonType.OPERATOR));
                add(new CalculatorButtonData("7", 3, 0, 1));
                add(new CalculatorButtonData("8", 3, 1, 1));
                add(new CalculatorButtonData("9", 3, 2, 1));
                add(new CalculatorButtonData(" * ", 3, 3, 1, CalculatorButtonData.ButtonType.OPERATOR));
                add(new CalculatorButtonData(".", 4, 0, 1));
                add(new CalculatorButtonData("0", 4, 1, 1));
                add(new CalculatorButtonData("CLEAR", 4, 2, 1, CalculatorButtonData.ButtonType.CLEAR));
                add(new CalculatorButtonData(" / ", 4, 3, 1, CalculatorButtonData.ButtonType.OPERATOR));
                add(new CalculatorButtonData("EQUALS", 5, 0, 4, CalculatorButtonData.ButtonType.EQUALS));
            }
        };


        // viewing window is added to the layout
        CalculatorDisplay display = new CalculatorDisplay(this);
        mainLayout.addView(display);

        CalculatorParser parser = new CalculatorParser();

        buttonData.forEach(data -> {
            CalculatorButton button = new CalculatorButton(this, data);
            button.setOnClickListener(view -> {
                if (data.buttonType == CalculatorButtonData.ButtonType.NUMBER) {
                    display.setText(display.getText().toString() + data.text);

                } else if (data.buttonType == CalculatorButtonData.ButtonType.CLEAR) {
                    display.setText("");
                } else if (data.buttonType == CalculatorButtonData.ButtonType.OPERATOR) {
                    display.setText(display.getText().toString() + data.text);
                } else { // user presses the equals button

                    try {
                        Double result = parser.evaluate(display.getText().toString());
                        String result1 = String.valueOf(result);
                        display.setText(result1);

                    } catch (Exception e) {
                        display.setText("There was something wrong with your input, press clear and try again");

                    }

                }
            });

            mainLayout.addView(button);
        });

        setContentView(mainLayout);

    }
}