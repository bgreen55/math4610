package com.example.bradleyscalculator;

import android.content.Context;
import android.view.Gravity;
import android.widget.GridLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;

public class CalculatorDisplay extends AppCompatTextView {

    public CalculatorDisplay(@NonNull Context context) {
        super(context);

        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.rowSpec = GridLayout.spec(0, 1, 1);
        params.columnSpec = GridLayout.spec(0, 4, 1);
        setBackgroundColor(getResources().getColor(R.color.other_color, null));
        setTextSize(38);
        setTextColor(getResources().getColor(R.color.white, null));
        setLayoutParams(params);

    }
}
