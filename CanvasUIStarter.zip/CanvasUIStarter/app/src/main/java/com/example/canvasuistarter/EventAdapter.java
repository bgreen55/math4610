package com.example.canvasuistarter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.canvasuistarter.api.models.UpcomingEvent;
import com.example.canvasuistarter.databinding.EventListItemBinding;

import java.util.ArrayList;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {
    ArrayList<UpcomingEvent> upcomingEvents;
    public EventAdapter(ArrayList<UpcomingEvent> upcomingEvents) { this.upcomingEvents = upcomingEvents; }


    @NonNull
    @Override
    public EventAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(EventListItemBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false));

    }

    @Override
    public void onBindViewHolder(@NonNull EventAdapter.ViewHolder holder, int position) {
        UpcomingEvent upcomingEvent = upcomingEvents.get(position);
        holder.binding.eventName.setText(upcomingEvent.title);

    }

    @Override
    public int getItemCount() {
        return upcomingEvents.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public EventListItemBinding binding;
        public ViewHolder(@NonNull EventListItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
