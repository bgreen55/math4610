package com.example.canvasuistarter.api.models;

public class UpcomingEvent {
    public String title;
}
