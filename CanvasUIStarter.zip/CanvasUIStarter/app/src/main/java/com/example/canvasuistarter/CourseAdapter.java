package com.example.canvasuistarter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.canvasuistarter.api.models.Course;
import com.example.canvasuistarter.databinding.CourseListItemBinding;

import java.util.ArrayList;

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.ViewHolder> {
    ArrayList<Course> courses;
    public CourseAdapter(ArrayList<Course> courses) {this.courses = courses; }


    @NonNull
    @Override
    public CourseAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(CourseListItemBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false));

    }

    @Override
    public void onBindViewHolder(@NonNull CourseAdapter.ViewHolder holder, int position) {
        Course course = courses.get(position);
        holder.binding.name.setText(course.name);

    }

    @Override
    public int getItemCount() {
        return courses.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public CourseListItemBinding binding;
        public ViewHolder(@NonNull CourseListItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
