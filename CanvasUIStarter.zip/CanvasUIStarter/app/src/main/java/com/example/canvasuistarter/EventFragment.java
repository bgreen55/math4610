package com.example.canvasuistarter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.view.menu.MenuView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.canvasuistarter.api.USUCanvasAPI;
import com.example.canvasuistarter.api.models.Course;
import com.example.canvasuistarter.api.models.UpcomingEvent;
import com.example.canvasuistarter.api.models.User;
import com.example.canvasuistarter.databinding.FragmentCourseBinding;
import com.example.canvasuistarter.databinding.FragmentUpcomingeventBinding;

import java.util.ArrayList;
import java.util.Arrays;

public class EventFragment extends Fragment {


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        FragmentUpcomingeventBinding binding = FragmentUpcomingeventBinding.inflate(inflater, container, false);

        return binding.getRoot();
    }


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        USUCanvasAPI api = USUCanvasAPI.getInstance(getContext());
        api.getUpcomingEvents(new USUCanvasAPI.OnRequestCompleteListener<UpcomingEvent>() {
            @Override
            public void onComplete(UpcomingEvent[] result, String errorMessage) {
                ArrayList<UpcomingEvent> upcomingEvents = new ArrayList<>();
                upcomingEvents.addAll(Arrays.asList(result));
                EventAdapter eventAdapter = new EventAdapter(upcomingEvents);
                RecyclerView eventRView = view.findViewById(R.id.eventRecycler);

                eventRView.setAdapter(eventAdapter);
                eventRView.setLayoutManager(new LinearLayoutManager(getContext()));
            }
        });


        super.onViewCreated(view, savedInstanceState);
    }
}
