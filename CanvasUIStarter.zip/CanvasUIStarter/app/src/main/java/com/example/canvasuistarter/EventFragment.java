package com.example.canvasuistarter;

import androidx.fragment.app.Fragment;

public class EventFragment extends Fragment {
}
