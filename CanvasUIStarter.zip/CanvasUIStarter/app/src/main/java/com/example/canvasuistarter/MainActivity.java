package com.example.canvasuistarter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuView;
import androidx.drawerlayout.widget.DrawerLayout;

import android.icu.text.CaseMap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.canvasuistarter.api.USUCanvasAPI;
import com.example.canvasuistarter.api.models.Course;
import com.example.canvasuistarter.api.models.UpcomingEvent;
import com.example.canvasuistarter.api.models.User;
import com.example.canvasuistarter.databinding.ActivityMainBinding;
import com.example.canvasuistarter.databinding.FragmentCourseBinding;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        USUCanvasAPI api = USUCanvasAPI.getInstance(this);
        api.getUser(new USUCanvasAPI.OnRequestCompleteListener<User>() {
            @Override
            public void onComplete(User[] result, String errorMessage) {
                MenuView.ItemView username = findViewById(R.id.profile_item);
                username.setTitle(result[0].name);
            }
        });

        api.getCourses(new USUCanvasAPI.OnRequestCompleteListener<Course>() {
            @Override
            public void onComplete(Course[] result, String errorMessage) {
                System.out.println();
            }
        });

        api.getUpcomingEvents(new USUCanvasAPI.OnRequestCompleteListener<UpcomingEvent>() {
            @Override
            public void onComplete(UpcomingEvent[] result, String errorMessage) {
                System.out.println();
            }
        });


        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        MaterialToolbar toolbar = findViewById(R.id.top_AppBar);
        NavigationView navigationView = findViewById(R.id.navigation_view);

        toolbar.setNavigationOnClickListener(view -> {
            drawerLayout.open();
        });

        navigationView.setNavigationItemSelectedListener(menuItem -> {

            menuItem.setCheckable(true);
            if (menuItem.getItemId() == R.id.course_item) {

                api.getUser(new USUCanvasAPI.OnRequestCompleteListener<User>() {
                    @Override
                    public void onComplete(User[] result, String errorMessage) {
                        MenuView.ItemView username = findViewById(R.id.profile_item);
                        username.setTitle(result[0].name);
                    }
                });

                // navigate to this fragment
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, new CourseFragment(), null)
                        .addToBackStack(null)
                        .commit();

            }
            if (menuItem.getItemId() == R.id.profile_item) {

                api.getUser(new USUCanvasAPI.OnRequestCompleteListener<User>() {
                    @Override
                    public void onComplete(User[] result, String errorMessage) {
                        MenuView.ItemView username = findViewById(R.id.profile_item);
                        username.setTitle(result[0].name);
                    }
                });

                // navigate to profile item
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, new ProfileFragment(), null)
                        .addToBackStack(null)
                        .commit();

            }
            if (menuItem.getItemId() == R.id.events_item) {

                api.getUser(new USUCanvasAPI.OnRequestCompleteListener<User>() {
                    @Override
                    public void onComplete(User[] result, String errorMessage) {
                        MenuView.ItemView username = findViewById(R.id.profile_item);
                        username.setTitle(result[0].name);
                    }
                });

                // navigate to events fragment
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, new EventFragment(), null)
                        .addToBackStack(null)
                        .commit();

            }

            return true;
        });

    }

}