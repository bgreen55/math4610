package com.example.canvasuistarter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;

import com.example.canvasuistarter.api.USUCanvasAPI;
import com.example.canvasuistarter.api.models.Course;
import com.example.canvasuistarter.api.models.UpcomingEvent;
import com.example.canvasuistarter.api.models.User;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;


// the recycler view goes in the fragments, not in the main activity


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        USUCanvasAPI api = USUCanvasAPI.getInstance(this);
        api.getUser(new USUCanvasAPI.OnRequestCompleteListener<User>() {
            @Override
            public void onComplete(User[] result, String errorMessage) {
                System.out.println();
            }
        });

        api.getCourses(new USUCanvasAPI.OnRequestCompleteListener<Course>() {
            @Override
            public void onComplete(Course[] result, String errorMessage) {
                System.out.println();
            }
        });

        api.getUpcomingEvents(new USUCanvasAPI.OnRequestCompleteListener<UpcomingEvent>() {
            @Override
            public void onComplete(UpcomingEvent[] result, String errorMessage) {
                System.out.println();
            }
        });


        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        MaterialToolbar toolbar = findViewById(R.id.top_AppBar);
        NavigationView navigationView = findViewById(R.id.navigation_view);

        toolbar.setNavigationOnClickListener(view -> {
            drawerLayout.open();
        });

        navigationView.setNavigationItemSelectedListener(menuItem -> {
            menuItem.setCheckable(true);
            if (menuItem.getItemId() == R.id.course_item) {
                // navigate to this fragment
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.course_item, CourseFragment.class, null)
                        .addToBackStack(null)
                        .commit();
            }
            if (menuItem.getItemId() == R.id.profile_item) {
                // navigate to profile item
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.profile_item, ProfileFragment.class, null)
                        .addToBackStack(null)
                        .commit();
            }
            if (menuItem.getItemId() == R.id.events_item){
                // navigate to events fragment
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.events_item, EventFragment.class, null)
                        .addToBackStack(null)
                        .commit();
            }

            return true;
        });

    }
}