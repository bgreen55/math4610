package com.example.canvasuistarter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.example.canvasuistarter.api.models.Course;

import java.util.ArrayList;

public class CourseFragment extends Fragment {

    RecyclerView courseRecycler = findViewById(R.id.course_recycler);

}
