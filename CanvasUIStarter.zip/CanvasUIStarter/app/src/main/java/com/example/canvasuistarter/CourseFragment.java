package com.example.canvasuistarter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.canvasuistarter.api.USUCanvasAPI;
import com.example.canvasuistarter.api.models.Course;
import com.example.canvasuistarter.api.models.User;
import com.example.canvasuistarter.databinding.FragmentCourseBinding;

import java.util.ArrayList;
import java.util.Arrays;

public class CourseFragment extends Fragment {


   @Nullable
   @Override
   public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       FragmentCourseBinding binding = FragmentCourseBinding.inflate(inflater, container, false);

       return binding.getRoot();
   }


   public void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);

   }


   @Override
   public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        USUCanvasAPI api = USUCanvasAPI.getInstance(getContext());
        api.getCourses(new USUCanvasAPI.OnRequestCompleteListener<Course>() {
            @Override
            public void onComplete(Course[] result, String errorMessage) {
                ArrayList<Course> courses = new ArrayList<>();
                courses.addAll(Arrays.asList(result));
                CourseAdapter courseAdapter = new CourseAdapter(courses);
                RecyclerView courseRView = view.findViewById(R.id.couresRecycler);

                courseRView.setAdapter(courseAdapter);
                courseRView.setLayoutManager(new LinearLayoutManager(getContext()));

            }
        });


        super.onViewCreated(view, savedInstanceState);
    }


}
