package com.usu.minesweeperstarter;

import android.content.Context;
import android.widget.GridLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;

public class LevelButton extends AppCompatButton {

    public LevelButton(@NonNull Context context, LevelButtonData data) {
        super(context);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.rowSpec = GridLayout.spec(data.row, 1, 1);
        params.columnSpec = GridLayout.spec(data.col, data.colSpan, 1);
        params.setMargins(10, 10, 10, 10);
        setText(data.text);
        setTextSize(30);
        setLayoutParams(params);


    }

}
