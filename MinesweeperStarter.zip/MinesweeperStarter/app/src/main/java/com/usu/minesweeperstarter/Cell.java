package com.usu.minesweeperstarter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Cell {

    // FEEL FREE TO CHANGE THESE!
    private int[] colors = {
            Color.BLUE,
            Color.GREEN,
            Color.RED,
            Color.rgb(0,0,100),
            Color.YELLOW,
            Color.CYAN,
            Color.MAGENTA,
            Color.BLACK,
            Color.rgb(50, 30, 10),
            Color.WHITE
    };

    public enum Type {
        MINE,
        NUMBER,
        EMPTY
    }

    private boolean isMarked = false;
    private boolean isSelected = false;
    private Type type;
    private float xPos;
    private float yPos;
    private float width;
    private float height;
    private int numNeighbors = 0;
    Context context;
    public Cell(float xPos, float yPos, float width, float height, Type type, Context context) {
        this.type = type;
        this.yPos = yPos;
        this.xPos = xPos;
        this.width = width;
        this.height = height;
        this.context = context;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public boolean isMarked() {
        return isMarked;
    }

    public void toggleMark() {
        isMarked = !isMarked;
    }

    public void select() {
        isSelected = true;
        isMarked = false;
    }

    public void setNumNeighbors(int numNeighbors) {
        this.numNeighbors = numNeighbors;
    }

    public void draw(Canvas canvas, Paint paint) {

        if (isSelected()) { // the cell has been exploded
            if (type == Type.MINE) {
                canvas.save();
                paint.setColor(Color.LTGRAY);
                canvas.translate(xPos, yPos);
                canvas.drawRect(0, 0, width, height, paint);
                canvas.restore();
                canvas.save();

                paint.setColor(Color.RED);
                paint.setStrokeWidth(width / 10);
                canvas.translate(xPos, yPos);
                canvas.drawLine(0, 0, width, height, paint);
                canvas.restore();
                canvas.save();
                canvas.translate(xPos, yPos);
                canvas.drawLine(0, height, width, 0, paint);
                paint.reset();
                canvas.restore();


            } else if (type == Type.NUMBER) {
                String num = String.valueOf(numNeighbors);
                canvas.save();
                paint.setColor(Color.LTGRAY);
                canvas.translate(xPos, yPos);
                canvas.drawRect(0, 0, width, height, paint);
                canvas.restore();


                if (num.equals("1")) {
                    canvas.save();
                    paint.setColor(Color.BLUE);
                    canvas.translate(xPos, yPos);
                    paint.setTextSize(50);
                    canvas.drawText(num,  width / 3, (8 * height) / 10, paint);
                    canvas.restore();
                } else if (num.equals("2")) {
                    canvas.save();
                    paint.setColor(Color.GREEN);
                    canvas.translate(xPos, yPos);
                    paint.setTextSize(50);
                    canvas.drawText(num,  width / 3, (8 * height) / 10, paint);
                    canvas.restore();
                } else if (num.equals("3")) {
                    canvas.save();
                    paint.setColor(Color.MAGENTA);
                    canvas.translate(xPos, yPos);
                    paint.setTextSize(50);
                    canvas.drawText(num,  width / 3, (8 * height) / 10, paint);
                    canvas.restore();
                } else if (num.equals("4")) {
                    canvas.save();
                    paint.setColor(colors[3]);
                    canvas.translate(xPos, yPos);
                    paint.setTextSize(50);
                    canvas.drawText(num,  width / 3, (8 * height) / 10, paint);
                    canvas.restore();
                } else if (num.equals("5")) {
                    canvas.save();
                    paint.setColor(Color.YELLOW);
                    canvas.translate(xPos, yPos);
                    paint.setTextSize(50);
                    canvas.drawText(num,  width / 3, (8 * height) / 10, paint);
                    canvas.restore();
                } else if (num.equals("6")) {
                    canvas.save();
                    paint.setColor(colors[8]);
                    canvas.translate(xPos, yPos);
                    paint.setTextSize(50);
                    canvas.drawText(num,  width / 3, (8 * height) / 10, paint);
                    canvas.restore();
                } else if (num.equals("7")) {
                    canvas.save();
                    paint.setColor(Color.CYAN);
                    canvas.translate(xPos, yPos);
                    paint.setTextSize(50);
                    canvas.drawText(num,  width / 3, (8 * height) / 10, paint);
                    canvas.restore();
                } else {
                    canvas.save();
                    paint.setColor(Color.RED);
                    canvas.translate(xPos, yPos);
                    paint.setTextSize(50);
                    canvas.drawText(num,  width / 3, (8 * height) / 10, paint);
                    canvas.restore();
                }
            // the cell is empty
            } else {
                canvas.save();
                paint.setColor(Color.LTGRAY);
                canvas.translate(xPos, yPos);
                canvas.drawRect(0, 0, width, height, paint);
                canvas.restore();
            }

        } else {   // draw the cell if it hasn't been exploded
            if (isMarked) {
                canvas.save();
                paint.setColor(Color.RED);
                canvas.translate(xPos, yPos);
                canvas.drawRect(0, 0, width, height, paint);
                canvas.restore();
                paint.reset();

            } else {
                canvas.save();
                paint.setColor(context.getResources().getColor(R.color.backGround, null));   // how do I access resource file to choose paint color
                canvas.translate(xPos, yPos);
                canvas.drawRect(0, 0, width, height, paint);
                canvas.restore();
                paint.reset();

            }
        }
        canvas.save();
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.YELLOW);
        canvas.translate(xPos, yPos);
        canvas.drawRect(0, 0, width, height, paint);
        canvas.restore();
        paint.reset();


    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }
}
