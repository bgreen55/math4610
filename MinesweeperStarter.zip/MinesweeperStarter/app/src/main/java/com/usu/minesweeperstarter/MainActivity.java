package com.usu.minesweeperstarter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.GridLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // main Layout
        GridLayout mainLayout = new GridLayout(this);
        mainLayout.setBackgroundColor(getResources().getColor(R.color.backGround, null));


        ArrayList<LevelButtonData> buttonData = new ArrayList<LevelButtonData>() {
            {
                add(new LevelButtonData("EASY", 1, 0, 1));
                add(new LevelButtonData("Intermediate", 2, 0, 1));
                add(new LevelButtonData("Expert", 3, 0, 1));
            }
        };

        // add title to the top of the screen
        NameDisplay title = new NameDisplay(this);
        title.setText("MINESWEEPER");
        mainLayout.addView(title);


        // level selection buttons, takes user to new activity
        buttonData.forEach(data -> {
            LevelButton button = new LevelButton(this, data);
            button.setOnClickListener(view -> {
                if (data.text == "EASY") {
                    Intent intent = new Intent(this, GameActivity.class);
                    intent.putExtra("gamemode", "easy");
                    this.startActivity(intent);

                } else if (data.text == "Intermediate") {
                    Intent intent = new Intent(this, GameActivity.class);
                    intent.putExtra("gamemode", "intermediate");
                    this.startActivity(intent);

                } else if (data.text == "Expert") {
                    Intent intent = new Intent(this, GameActivity.class);
                    intent.putExtra("gamemode", "expert");
                    this.startActivity(intent);

                } else {
                    // exit program button
                }
            });
            mainLayout.addView(button);

        });


        setContentView(mainLayout);



        // TODO: create the views for the main page and transition
        //  to the main page once the difficulty is selected
    }
}