package com.usu.minesweeperstarter;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Game {
    private enum State {
        PLAY,
        WIN,
        LOSE,
    }

    Cell[][] cells;
    int mineCount;
    int rows = 30;
    int cols = 16;
    double cellWidth;
    double cellHeight;
    int screenWidth;
    int screenHeight;
    State state = State.PLAY;

    public Game(String gameMode, int screenWidth, int screenHeight) {
        cells = new Cell[rows][cols];
        if (gameMode.equals("expert")) {
            mineCount = 100;
        } else if (gameMode.equals("intermediate")) {
            mineCount = 50;
        } else {
            mineCount = 10;
        }
        cellHeight = (double)screenHeight / rows;
        cellWidth = (double)screenWidth / cols;
        this.screenHeight = screenHeight;
        this.screenWidth = screenWidth;
        initCells();
    }

    private void initCells() {
       //  create all cells, randomly assigning cells to be mines depending on difficulty.
        // HINT: 1. Create an ArrayList of Booleans
        //      2. set the first n (where n is number of mines you want) to be true
        //      3. set the remaining to be false (the total number of items in the list should be rows * cols)
        //      4. then shuffle the array list using Collections.shuffle()
        //      5. Then you can use this arraylist like a queue when iterating of your grid

        ArrayList<Boolean> mineList = new ArrayList<Boolean>() {
            {
             // add all the mines to the list
             for (int i = 0; i < mineCount; i ++) {
                 add(new Boolean(Boolean.TRUE));
             }
             // add empty cells to list
             for (int j = 0; j < ((rows * cols) - mineCount); j ++) {
                 add(new Boolean(Boolean.FALSE));
             }
            }
        };

        // shuffle mine list so mines are place randomly
        Collections.shuffle(mineList);

        // use the minelist to initiate the cell objects
        for(int i = 0; i < rows; i ++) {
            for (int j = 0; j < cols; j ++) {
                if (mineList.remove(0) == true) {
                    cells[i][j].setType(Cell.Type.MINE);
                } else {
                    if (countNeighbors(i, j, cells) == 0) {
                        cells[i][j].setType(Cell.Type.EMPTY);
                    } else {
                        cells[i][j].setType(Cell.Type.NUMBER);
                    }
                }
            }
        }

    }


    private int countNeighbors(int row, int col, Cell[][] cells) {
        //  Count how many mines surround the cell at (row, col);
        int sum = 0;

        for (int i = -1; i < 2; i ++) {
            for (int j = -1; j < 2; j ++) {
                if(i == 0 && j == 0) {
                    continue; // this is the cell that we are checking the neighbors for so do nothing
                } else if (cells[row + i][col + j].getType() == Cell.Type.MINE) {
                    sum ++;
                }
            }
        }
        return sum;
    }

    private void revealMines() {
        // TODO: loop through the cells and select all mines


    }

    private void explodeBlankCells(int row, int col) {
        // recursively select all surrounding cells, only stopping when you reach a cell that has already been selected, or when you select a cell that is not Empty
        if (row < 0 || row >= cells.length) return;
        if (col < 0 || col >= cells[row].length) return;
        cells[row][col].select();
        if (cells[row][col].getType() == Cell.Type.NUMBER) return;

        explodeBlankCells(row - 1, col - 1);
        explodeBlankCells(row - 1, col);
        explodeBlankCells(row - 1, col + 1);
        explodeBlankCells(row, col - 1);
        explodeBlankCells(row, col + 1);
        explodeBlankCells(row + 1, col - 1);
        explodeBlankCells(row + 1, col);
        explodeBlankCells(row + 1, col + 1);

    }


    public void handleTap(MotionEvent e) {
        // TODO: find the cell the player tapped
        //      Depending on what type of cell they tapped
        //         mine: select the cell, reveal the mines, and set the game to the LOSE state
        //         empty cell: select the cell and explode the surrounding cells
        //         all others: simply select the cell
    }

    public void handleLongPress(MotionEvent e) {
        // TODO: find the cell and toggle its mark
        //       then check to see if the player won the game
    }


    public void draw(Canvas canvas, Paint paint) {
        for(int i = 0; i < cells.length; i++) {
            for (int j = 0; j < cells[i].length; j++) {
                cells[i][j].draw(canvas, paint);
                paint.reset();
            }
        }

        if (state == State.WIN) {
            // TODO draw a win screen here
            //paint.setColor(getResources().getColor(R.color.backGround, null));        ???
           canvas.save();
           paint.setColor(Color.BLACK);
           paint.setTextSize(300);
           canvas.drawText("YOU", screenWidth / 5, screenHeight / 3, paint);
           canvas.restore();
           canvas.drawText("WON", screenWidth / 6, 2 * screenHeight / 3, paint);
        }
    }


    public void selectCell(int row, int col) {
        if (state != State.PLAY) return;
        if (cells[row][col].getType() == Cell.Type.MINE) {
            cells[row][col].select();
            state = State.LOSE;
            revealMines();
        } else if (cells[row][col].getType() == Cell.Type.EMPTY) {
            explodeBlankCells(row, col);
        } else {
            cells[row][col].select();
        }
    }


}
