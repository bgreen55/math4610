package com.usu.minesweeperstarter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Game {
    private enum State {
        PLAY,
        WIN,
        LOSE,
    }

    Cell[][] cells;
    int mineCount;
    int rows = 30;
    int cols = 16;
    double cellWidth;
    double cellHeight;
    int screenWidth;
    int screenHeight;
    State state = State.PLAY;
    Context context;

    public Game(String gameMode, int screenWidth, int screenHeight, Context context) {
        cells = new Cell[rows][cols];
        if (gameMode.equals("expert")) {
            mineCount = 100;
        } else if (gameMode.equals("intermediate")) {
            mineCount = 50;
        } else {
            mineCount = 10;
        }
        cellHeight = (double)screenHeight / rows;
        cellWidth = (double)screenWidth / cols;
        this.screenHeight = screenHeight;
        this.screenWidth = screenWidth;
        this.context = context;
        initCells();
    }

    private void initCells() {
       //  create all cells, randomly assigning cells to be mines depending on difficulty.
        //      1. Create an ArrayList of Booleans
        //      2. set the first n (where n is number of mines you want) to be true
        //      3. set the remaining to be false (the total number of items in the list should be rows * cols)
        //      4. then shuffle the array list using Collections.shuffle()
        //      5. Then you can use this arraylist like a queue when iterating of your grid

        ArrayList<Boolean> mineList = new ArrayList<Boolean>() {
            {
             // add all the mines to the list
             for (int i = 0; i < mineCount; i ++) {
                 add(new Boolean(Boolean.TRUE));
             }
             // add empty cells to list
             for (int j = 0; j < ((rows * cols) - mineCount); j ++) {
                 add(new Boolean(Boolean.FALSE));
             }
            }
        };

        // shuffle mine list so mines are place randomly
        Collections.shuffle(mineList);

        // use the minelist to initiate the cell objects
        for(int i = 0; i < rows; i ++) {
            for (int j = 0; j < cols; j ++) {
                cells[i][j] = new Cell((float) (j * cellWidth), (float) (i * cellHeight), (float)cellWidth, (float)cellHeight, Cell.Type.EMPTY, context);

                if (mineList.remove(0) == true) {
                    cells[i][j].setType(Cell.Type.MINE);
                }
            }
        }
        for (int i = 0; i < rows; i ++) {
            for (int j = 0; j < cols; j ++) {
                int count = countNeighbors(i, j, cells);
                if (cells[i][j].getType() == Cell.Type.MINE) { continue; }
                if (count == 0) {
                    cells[i][j].setType(Cell.Type.EMPTY);
                } else {
                    cells[i][j].setType(Cell.Type.NUMBER);
                    cells[i][j].setNumNeighbors(count);
                }
            }
        }

    }


    private int countNeighbors(int row, int col, Cell[][] cells) {
        //  Count how many mines surround the cell at (row, col);
        int sum = 0;

        for (int i = -1; i < 2; i ++) {
            for (int j = -1; j < 2; j ++) {
                if(i == 0 && j == 0) {
                    continue; // this is the cell that we are checking the neighbors for so do nothing
                } else if (row + i > -1 && row + i < rows && col + j > -1 && col + j < cols &&
                        cells[row + i][col + j].getType() == Cell.Type.MINE) {
                    sum ++;
                }
            }
        }
        return sum;
    }

    private void revealMines() {
        //  loop through the cells and select all mines
        for (int i = 0; i < rows; i ++) {
            for (int j = 0; j < cols; j ++) {
                cells[i][j].select();
            }
        }


    }

    private void explodeBlankCells(int row, int col) {
        // recursively select all surrounding cells, only stopping when you reach a cell that has already been selected, or when you select a cell that is not Empty
        if (row < 0 || row >= cells.length) return;
        if (col < 0 || col >= cells[row].length) return;
        if (cells[row][col].isSelected()) return;
        cells[row][col].select();
        if (cells[row][col].getType() == Cell.Type.NUMBER) return;

        explodeBlankCells(row - 1, col - 1);
        explodeBlankCells(row - 1, col);
        explodeBlankCells(row - 1, col + 1);
        explodeBlankCells(row, col - 1);
        explodeBlankCells(row, col + 1);
        explodeBlankCells(row + 1, col - 1);
        explodeBlankCells(row + 1, col);
        explodeBlankCells(row + 1, col + 1);

    }


    public void handleTap(MotionEvent e) {
        // : find the cell the player tapped
        //      Depending on what type of cell they tapped
        //         mine: select the cell, reveal the mines, and set the game to the LOSE state
        //         empty cell: select the cell and explode the surrounding cells
        //         all others: simply select the cell

        if (state != State.PLAY) return;
        int row = (int)(e.getY() / cellHeight);
        int col = (int)(e.getX() / cellWidth);

        // if the cell has a mine
        if (cells[row][col].getType() == Cell.Type.MINE) {
            //explodeBlankCells(row, col);
            cells[row][col].select();
            state = State.LOSE;
            revealMines();
        // if the cell is empty
        } else if (cells[row][col].getType() == Cell.Type.EMPTY) {
            explodeBlankCells(row, col);
        // if the cell has a number
        } else {
            //explodeBlankCells(row, col);
            cells[row][col].select();
        }

    }

    public void handleLongPress(MotionEvent e) {
        //  find the cell and toggle its mark
        //       then check to see if the player won the game

        if (state != State.PLAY) return;
        int row = (int)(e.getY() / cellHeight);
        int col = (int)(e.getX() / cellWidth);

        if (cells[row][col].isSelected() == false) {
            cells[row][col].toggleMark();
        }
        // check to see if all the correct mines have been selected
        int correctSelected = 0;
        int multiplier = 1;
        for (int i = 0; i < rows; i ++) {
            for (int j = 0; j < cols; j ++) {
                // if a mine is selected, add it to the correct amount of selected mines
                if (cells[i][j].getType() == Cell.Type.MINE && cells[i][j].isMarked()) {
                    correctSelected ++;
                }
                if (cells[i][j].getType() != Cell.Type.MINE && cells[i][j].isMarked()) {
                    multiplier = 0;
                }
            }
        }
        if ((correctSelected * multiplier) == mineCount) {
            state = State.WIN;
        }


    }


    public void draw(Canvas canvas, Paint paint) {
        for (int i = 0; i < cells.length; i++) {
            for (int j = 0; j < cells[i].length; j++) {
                cells[i][j].draw(canvas, paint);
                paint.reset();
            }
        }

        if (state == State.WIN) {
            //  draw a win screen here
           canvas.save();
           paint.setColor(Color.BLACK);
           paint.setTextSize(300);
           canvas.drawText("YOU", screenWidth / 5, screenHeight / 3, paint);
           canvas.restore();
           canvas.drawText("WON", screenWidth / 6, 2 * screenHeight / 3, paint);
        }
    }




}
