package com.usu.minesweeperstarter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.GridLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;

public class NameDisplay extends AppCompatTextView {

    public NameDisplay(@NonNull Context context) {
        super(context);

        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.rowSpec = GridLayout.spec(0, 1, 1);
        params.columnSpec = GridLayout.spec(0,1, 1);
        setTextSize(45);
        setTypeface(null, Typeface.BOLD);
        setTextColor(getResources().getColor(R.color.black, null));
        setGravity(Gravity.CENTER);
        setLayoutParams(params);
    }
}
